const CACHE_NAME = 'smart-upi-qr-pro-v26';

const CORE_ASSETS = [
  './Smart_UPI_QR_Studio_Pro_Final.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

const CDN_ASSETS = [
  'https://cdn.tailwindcss.com',
  'https://unpkg.com/lucide@latest',
  'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js',
  'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // 1. Cache core files safely
      for (const url of CORE_ASSETS) {
        try {
          await cache.add(url);
        } catch (err) {
          console.warn(`[SW] Local asset cache notice for ${url}:`, err);
        }
      }
      // 2. Pre-cache external CDNs
      for (const url of CDN_ASSETS) {
        try {
          await cache.add(new Request(url, { mode: 'cors' }));
        } catch (err) {
          console.warn(`[SW] CDN cache notice for ${url}:`, err);
        }
      }
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Handle standalone app launch & page navigations
  if (request.mode === 'navigate') {
    event.respondWith(
      caches.match('./Smart_UPI_QR_Studio_Pro_Final.html').then((cachedPage) => {
        if (cachedPage) {
          fetch(request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put('./Smart_UPI_QR_Studio_Pro_Final.html', networkResponse));
            }
          }).catch(() => {});
          return cachedPage;
        }
        return fetch(request);
      }).catch(() => caches.match('./Smart_UPI_QR_Studio_Pro_Final.html'))
    );
    return;
  }

  // Handle assets, scripts, fonts, and images
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200) {
          return networkResponse;
        }
        const responseToCache = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(request, responseToCache);
        });
        return networkResponse;
      }).catch(() => {
        return new Response('', { status: 408, statusText: 'Offline' });
      });
    })
  );
});

