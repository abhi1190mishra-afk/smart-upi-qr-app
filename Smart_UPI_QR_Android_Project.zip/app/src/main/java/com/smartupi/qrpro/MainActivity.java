package com.smartupi.qrpro;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private PermissionRequest pendingPermissionRequest;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1001;

    private ValueCallback<Uri[]> fileUploadCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private ActivityResultLauncher<Intent> saveDocumentLauncher;

    private String pendingExportContent = "";
    private String pendingExportMimeType = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Native file chooser launcher for gallery QR scan and JSON restore
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (fileUploadCallback == null) return;
                    Uri[] results = null;
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        if (data.getData() != null) {
                            results = new Uri[]{data.getData()};
                        } else if (data.getClipData() != null) {
                            int count = data.getClipData().getItemCount();
                            results = new Uri[count];
                            for (int i = 0; i < count; i++) {
                                results[i] = data.getClipData().getItemAt(i).getUri();
                            }
                        }
                    }
                    fileUploadCallback.onReceiveValue(results);
                    fileUploadCallback = null;
                }
        );

        // Native Storage Access Framework (SAF) launcher for "Save As / Path Selection"
        saveDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                        Uri uri = result.getData().getData();
                        try {
                            OutputStream os = getContentResolver().openOutputStream(uri);
                            if (os != null) {
                                if ("application/pdf".equals(pendingExportMimeType)) {
                                    String cleanBase64 = pendingExportContent;
                                    if (cleanBase64.contains(",")) {
                                        cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                                    }
                                    byte[] bytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                                    os.write(bytes);
                                } else {
                                    os.write(pendingExportContent.getBytes(StandardCharsets.UTF_8));
                                }
                                os.flush();
                                os.close();
                                Toast.makeText(MainActivity.this, "✓ File saved successfully to chosen location!", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Save error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );

        webView = findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Hardware acceleration support
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);

        // Register Android Javascript Interface
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            // Camera permission for live scanner
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                                == PackageManager.PERMISSION_GRANTED) {
                            request.grant(request.getResources());
                        } else {
                            pendingPermissionRequest = request;
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.CAMERA},
                                    CAMERA_PERMISSION_REQUEST_CODE);
                        }
                        return;
                    }
                }
                request.grant(request.getResources());
            }

            // Gallery file picker for QR code images & backup JSON files
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                fileUploadCallback = filePathCallback;

                try {
                    Intent intent = fileChooserParams.createIntent();
                    fileChooserLauncher.launch(intent);
                    return true;
                } catch (Exception e) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        fileChooserLauncher.launch(intent);
                        return true;
                    } catch (Exception ex) {
                        if (fileUploadCallback != null) {
                            fileUploadCallback.onReceiveValue(null);
                            fileUploadCallback = null;
                        }
                        return false;
                    }
                }
            }
        });

        // Load local offline assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    // Native Bridge class exposed to JavaScript
    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        // Native Path-Selection Save for Backups (JSON) & Reports (PDF)
        @JavascriptInterface
        public void exportDocument(String content, String mimeType, String defaultFilename) {
            runOnUiThread(() -> {
                try {
                    pendingExportContent = content;
                    pendingExportMimeType = mimeType;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, defaultFilename);
                    saveDocumentLauncher.launch(intent);
                } catch (Exception e) {
                    Toast.makeText(mContext, "Export picker error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Native Android Share for PDF & Text
        @JavascriptInterface
        public void shareDocument(String content, String mimeType, String filename, String title, String text) {
            runOnUiThread(() -> {
                try {
                    File cachePath = new File(getCacheDir(), "documents");
                    cachePath.mkdirs();
                    File docFile = new File(cachePath, filename);
                    FileOutputStream fos = new FileOutputStream(docFile);

                    if ("application/pdf".equals(mimeType)) {
                        String cleanBase64 = content;
                        if (cleanBase64.contains(",")) cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                        byte[] bytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                        fos.write(bytes);
                    } else {
                        fos.write(content.getBytes(StandardCharsets.UTF_8));
                    }
                    fos.flush();
                    fos.close();

                    Uri contentUri = FileProvider.getUriForFile(mContext, getPackageName() + ".fileprovider", docFile);
                    if (contentUri != null) {
                        Intent shareIntent = new Intent(Intent.ACTION_SEND);
                        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        shareIntent.setDataAndType(contentUri, mimeType);
                        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                        shareIntent.putExtra(Intent.EXTRA_SUBJECT, title);
                        shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(shareIntent, "Share via"));
                    }
                } catch (Exception e) {
                    Toast.makeText(mContext, "Share error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Image Download to Gallery/Pictures
        @JavascriptInterface
        public void downloadImage(String base64Data, String filename) {
            try {
                String cleanBase64 = base64Data;
                if (cleanBase64.contains(",")) {
                    cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                }
                byte[] decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

                OutputStream fos;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/UPI_QR");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri != null) {
                        fos = getContentResolver().openOutputStream(uri);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        if (fos != null) fos.close();
                    }
                } else {
                    File imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                    File imageFile = new File(imagesDir, filename);
                    fos = new FileOutputStream(imageFile);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.close();
                }

                runOnUiThread(() -> Toast.makeText(mContext, "✓ QR Code saved to Gallery!", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(mContext, "Download notice: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }

        // Image Native Share (WhatsApp, Bluetooth, etc.)
        @JavascriptInterface
        public void shareImage(String base64Data, String title, String text) {
            try {
                String cleanBase64 = base64Data;
                if (cleanBase64.contains(",")) {
                    cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                }
                byte[] decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

                File cachePath = new File(getCacheDir(), "images");
                cachePath.mkdirs();
                File imageFile = new File(cachePath, "shared_upi_qr.png");
                FileOutputStream stream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                stream.close();

                Uri contentUri = FileProvider.getUriForFile(mContext, getPackageName() + ".fileprovider", imageFile);

                if (contentUri != null) {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    shareIntent.setDataAndType(contentUri, getContentResolver().getType(contentUri));
                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, title);
                    shareIntent.putExtra(Intent.EXTRA_TEXT, text);

                    Intent chooser = Intent.createChooser(shareIntent, "Share QR via");
                    startActivity(chooser);
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(mContext, "Share notice: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }

        // Biometric / Fingerprint Authentication
        @JavascriptInterface
        public void authenticateBiometric(String title, String subtitle) {
            runOnUiThread(() -> {
                try {
                    BiometricManager biometricManager = BiometricManager.from(MainActivity.this);
                    int canAuth = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
                    if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
                        Executor executor = ContextCompat.getMainExecutor(MainActivity.this);
                        BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this, executor,
                                new BiometricPrompt.AuthenticationCallback() {
                                    @Override
                                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                                        super.onAuthenticationSucceeded(result);
                                        webView.evaluateJavascript("window.onBiometricSuccess && window.onBiometricSuccess();", null);
                                    }

                                    @Override
                                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                                        super.onAuthenticationError(errorCode, errString);
                                        webView.evaluateJavascript("window.onBiometricFallback && window.onBiometricFallback();", null);
                                    }

                                    @Override
                                    public void onAuthenticationFailed() {
                                        super.onAuthenticationFailed();
                                    }
                                });

                        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setSubtitle(subtitle)
                                .setNegativeButtonText("Use PIN")
                                .build();

                        biometricPrompt.authenticate(promptInfo);
                    } else {
                        // Device has no fingerprint sensor (e.g. Car Tablet) -> Fallback to PIN
                        webView.evaluateJavascript("window.onBiometricFallback && window.onBiometricFallback();", null);
                    }
                } catch (Exception e) {
                    webView.evaluateJavascript("window.onBiometricFallback && window.onBiometricFallback();", null);
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                    pendingPermissionRequest = null;
                }
            } else {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.deny();
                    pendingPermissionRequest = null;
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
