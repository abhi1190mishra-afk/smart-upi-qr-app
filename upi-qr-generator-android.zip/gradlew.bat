@rem Gradle startup script for Windows
@rem Fallback execution
gradle %*
