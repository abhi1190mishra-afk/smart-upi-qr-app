package com.upiqr.generator.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.upiqr.generator.model.QrPaymentRequest
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object QrGenerator {

    fun generateQrBitmap(content: String, size: Int = 800): Bitmap {
        val hints = mutableMapOf<EncodeHintType, Any>()
        hints[EncodeHintType.MARGIN] = 1
        hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.H

        val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)

        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE)
            }
        }
        return bitmap
    }

    fun createBrandedQrCard(request: QrPaymentRequest): Bitmap {
        val qrBitmap = generateQrBitmap(request.buildUpiUri(), 700)
        val cardWidth = 900
        val cardHeight = 1200

        val cardBitmap = Bitmap.createBitmap(cardWidth, cardHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(cardBitmap)

        val bgPaint = Paint().apply {
            color = AndroidColor.WHITE
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, cardWidth.toFloat(), cardHeight.toFloat(), bgPaint)

        val headerPaint = Paint().apply {
            color = AndroidColor.parseColor("#0F172A")
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(40f, 40f, (cardWidth - 40).toFloat(), 220f), 24f, 24f, headerPaint)

        val titlePaint = Paint().apply {
            color = AndroidColor.WHITE
            textSize = 52f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(request.upiAccount.name, (cardWidth / 2).toFloat(), 125f, titlePaint)

        val subPaint = Paint().apply {
            color = AndroidColor.parseColor("#94A3B8")
            textSize = 34f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(request.upiAccount.upiId, (cardWidth / 2).toFloat(), 185f, subPaint)

        val qrRect = Rect(0, 0, qrBitmap.width, qrBitmap.height)
        val destRect = Rect(100, 270, cardWidth - 100, 970)
        canvas.drawBitmap(qrBitmap, qrRect, destRect, null)

        val bottomBgPaint = Paint().apply {
            color = AndroidColor.parseColor("#F8FAFC")
            isAntiAlias = true
        }
        canvas.drawRoundRect(RectF(60f, 1000f, (cardWidth - 60).toFloat(), 1140f), 20f, 20f, bottomBgPaint)

        val bottomTextPaint = Paint().apply {
            color = AndroidColor.parseColor("#0F172A")
            textSize = 46f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val hasAmount = request.amount.trim().isNotEmpty() && request.amount != "0"
        if (hasAmount) {
            canvas.drawText("AMOUNT: ₹${request.amount}", (cardWidth / 2).toFloat(), 1085f, bottomTextPaint)
        } else {
            val scanTextPaint = Paint().apply {
                color = AndroidColor.parseColor("#475569")
                textSize = 36f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("SCAN & PAY WITH ANY UPI APP", (cardWidth / 2).toFloat(), 1085f, scanTextPaint)
        }

        return cardBitmap
    }

    fun saveCardToGallery(context: Context, cardBitmap: Bitmap): Boolean {
        val filename = "UPI_QR_${System.currentTimeMillis()}.png"
        var fos: OutputStream? = null
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/UPI_QR")
                }
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (imageUri != null) {
                    fos = resolver.openOutputStream(imageUri)
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
                val dir = File(imagesDir, "UPI_QR")
                if (!dir.exists()) dir.mkdirs()
                val image = File(dir, filename)
                fos = FileOutputStream(image)
            }
            fos?.let {
                cardBitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                true
            } ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        } finally {
            fos?.close()
        }
    }

    fun shareQrCode(context: Context, request: QrPaymentRequest) {
        try {
            val cardBitmap = createBrandedQrCard(request)
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs()
            val stream = FileOutputStream(File(cachePath, "shared_upi_qr.png"))
            cardBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()

            val newFile = File(cachePath, "shared_upi_qr.png")
            val contentUri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", newFile)

            val hasAmount = request.amount.trim().isNotEmpty() && request.amount != "0"
            val shareText = if (hasAmount) {
                "Payment Request: ₹${request.amount}\nMerchant: ${request.upiAccount.name}\nUPI ID: ${request.upiAccount.upiId}\n\nPay using link: ${request.buildUpiUri()}"
            } else {
                "UPI Payment Details:\nMerchant: ${request.upiAccount.name}\nUPI ID: ${request.upiAccount.upiId}\n\nPay using link: ${request.buildUpiUri()}"
            }

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                setDataAndType(contentUri, context.contentResolver.getType(contentUri))
                putExtra(Intent.EXTRA_STREAM, contentUri as Parcelable)
                putExtra(Intent.EXTRA_TEXT, shareText)
                type = "image/png"
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share UPI QR"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
