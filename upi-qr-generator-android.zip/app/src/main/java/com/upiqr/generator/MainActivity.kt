package com.upiqr.generator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.theme.AppThemeMode
import com.upiqr.generator.theme.getPalette
import com.upiqr.generator.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var themeMode by remember { mutableStateOf(AppThemeMode.AUTO) }
            var currentLanguage by remember { mutableStateOf(AppLanguage.HI) }

            val isSystemDark = isSystemInDarkTheme()
            val palette = remember(themeMode, isSystemDark) {
                getPalette(themeMode, isSystemDark)
            }

            HomeScreen(
                palette = palette,
                themeMode = themeMode,
                onThemeChange = { themeMode = it },
                language = currentLanguage,
                onLanguageChange = { currentLanguage = it }
            )
        }
    }
}
