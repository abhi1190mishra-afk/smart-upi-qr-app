package com.upiqr.generator

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.theme.AppThemeMode
import com.upiqr.generator.theme.getPalette
import com.upiqr.generator.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = getSharedPreferences("upi_qr_prefs", Context.MODE_PRIVATE)

        setContent {
            // Restore persistent theme mode
            var themeMode by remember {
                val savedTheme = prefs.getString("app_theme_mode", AppThemeMode.AUTO.name)
                mutableStateOf(try { AppThemeMode.valueOf(savedTheme ?: AppThemeMode.AUTO.name) } catch (_: Exception) { AppThemeMode.AUTO })
            }

            // Restore persistent language
            var currentLanguage by remember {
                val savedLang = prefs.getString("app_language", AppLanguage.HI.name)
                mutableStateOf(try { AppLanguage.valueOf(savedLang ?: AppLanguage.HI.name) } catch (_: Exception) { AppLanguage.HI })
            }

            val isSystemDark = isSystemInDarkTheme()
            val palette = remember(themeMode, isSystemDark) {
                getPalette(themeMode, isSystemDark)
            }

            HomeScreen(
                palette = palette,
                themeMode = themeMode,
                onThemeChange = { newMode ->
                    themeMode = newMode
                    prefs.edit().putString("app_theme_mode", newMode.name).apply()
                },
                language = currentLanguage,
                onLanguageChange = { newLang ->
                    currentLanguage = newLang
                    prefs.edit().putString("app_language", newLang.name).apply()
                }
            )
        }
    }
}
