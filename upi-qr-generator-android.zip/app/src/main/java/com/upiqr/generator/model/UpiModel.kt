package com.upiqr.generator.model

import org.json.JSONArray
import org.json.JSONObject

data class UpiAccount(
    val id: String,
    val name: String,
    val upiId: String,
    val isDefault: Boolean = false
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("name", name)
        obj.put("upiId", upiId)
        obj.put("isDefault", isDefault)
        return obj
    }

    companion object {
        fun fromJson(obj: JSONObject): UpiAccount {
            return UpiAccount(
                id = obj.optString("id", System.currentTimeMillis().toString()),
                name = obj.optString("name", "Store"),
                upiId = obj.optString("upiId", "merchant@upi"),
                isDefault = obj.optBoolean("isDefault", false)
            )
        }

        fun listToJson(list: List<UpiAccount>): String {
            val array = JSONArray()
            list.forEach { array.put(it.toJson()) }
            return array.toString()
        }

        fun listFromJson(jsonStr: String): List<UpiAccount> {
            val list = mutableListOf<UpiAccount>()
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    list.add(fromJson(array.getJSONObject(i)))
                }
            } catch (_: Exception) {}
            return if (list.isEmpty()) defaultAccounts() else list
        }

        fun defaultAccounts(): List<UpiAccount> = listOf(
            UpiAccount("1", "Main Store", "merchant@upi", isDefault = true),
            UpiAccount("2", "Paytm Business", "9876543210@paytm"),
            UpiAccount("3", "HDFC UPI", "shop@hdfcbank")
        )
    }
}

data class QrPaymentRequest(
    val upiAccount: UpiAccount,
    val amount: String,
    val note: String
) {
    fun buildUpiUri(): String {
        val cleanAmount = amount.trim()
        val encodedName = java.net.URLEncoder.encode(upiAccount.name, "UTF-8").replace("+", "%20")
        val encodedNote = java.net.URLEncoder.encode(note.trim(), "UTF-8").replace("+", "%20")

        val sb = StringBuilder("upi://pay?")
        sb.append("pa=").append(upiAccount.upiId.trim())
        sb.append("&pn=").append(encodedName)
        sb.append("&cu=INR")

        if (cleanAmount.length > 0 && cleanAmount != "0") {
            sb.append("&am=").append(cleanAmount)
        }
        if (note.trim().length > 0) {
            sb.append("&tn=").append(encodedNote)
        }
        return sb.toString()
    }
}
