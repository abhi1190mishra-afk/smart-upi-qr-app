package com.upiqr.generator.model

data class UpiAccount(
    val id: String,
    val name: String,
    val upiId: String,
    val isDefault: Boolean = false
) {
    fun toSerialized(): String = "$id|$name|$upiId|$isDefault"

    companion object {
        fun fromSerialized(line: String): UpiAccount? {
            val parts = line.split("|")
            return if (parts.size >= 3) {
                UpiAccount(
                    id = parts[0],
                    name = parts[1],
                    upiId = parts[2],
                    isDefault = parts.getOrNull(3)?.toBoolean() ?: false
                )
            } else null
        }

        fun listToJson(list: List<UpiAccount>): String {
            return list.joinToString(";;") { it.toSerialized() }
        }

        fun listFromJson(jsonStr: String): List<UpiAccount> {
            val list = mutableListOf<UpiAccount>()
            try {
                val items = jsonStr.split(";;")
                for (item in items) {
                    val acc = fromSerialized(item)
                    if (acc != null) list.add(acc)
                }
            } catch (_: Exception) {}
            return if (list.size > 0) list else defaultAccounts()
        }

        fun defaultAccounts(): List<UpiAccount> = listOf(
            UpiAccount("1", "Main Store", "merchant@upi", isDefault = true),
            UpiAccount("2", "Paytm Business", "9876543210@paytm"),
            UpiAccount("3", "HDFC UPI", "shop@hdfcbank")
        )
    }
}

data class QrPaymentRequest(
    val upiAccount: UpiAccount,
    val amount: String,
    val note: String
) {
    fun buildUpiUri(): String {
        val cleanAmount = amount.trim()
        val encodedName = java.net.URLEncoder.encode(upiAccount.name, "UTF-8").replace("+", "%20")
        val encodedNote = java.net.URLEncoder.encode(note.trim(), "UTF-8").replace("+", "%20")

        val sb = StringBuilder("upi://pay?")
        sb.append("pa=").append(upiAccount.upiId.trim())
        sb.append("&pn=").append(encodedName)
        sb.append("&cu=INR")

        if (cleanAmount != "" && cleanAmount != "0") {
            sb.append("&am=").append(cleanAmount)
        }
        if (note.trim() != "") {
            sb.append("&tn=").append(encodedNote)
        }
        return sb.toString()
    }
}
