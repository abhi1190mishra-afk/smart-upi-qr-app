package com.upiqr.generator.model

data class UpiAccount(
    val id: String,
    val name: String,
    val upiId: String,
    val isDefault: Boolean = false
)

data class QrPaymentRequest(
    val upiAccount: UpiAccount,
    val amount: String,
    val note: String
) {
    fun buildUpiUri(): String {
        val cleanAmount = amount.trim()
        val encodedName = java.net.URLEncoder.encode(upiAccount.name, "UTF-8").replace("+", "%20")
        val encodedNote = java.net.URLEncoder.encode(note.trim(), "UTF-8").replace("+", "%20")
        
        val sb = StringBuilder("upi://pay?")
        sb.append("pa=").append(upiAccount.upiId.trim())
        sb.append("&pn=").append(encodedName)
        sb.append("&cu=INR")
        
        if (cleanAmount.isNotEmpty() && cleanAmount != "0") {
            sb.append("&am=").append(cleanAmount)
        }
        if (note.trim().isNotEmpty()) {
            sb.append("&tn=").append(encodedNote)
        }
        return sb.toString()
    }
}
