package com.upiqr.generator.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.QrPaymentRequest
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.CustomPalette
import com.upiqr.generator.util.QrGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun QrPopupModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    amount: String,
    note: String,
    currentAccount: UpiAccount,
    allAccounts: List<UpiAccount>,
    onAccountChange: (UpiAccount) -> Unit,
    palette: CustomPalette,
    lang: AppLanguage
) {
    if (!isOpen) return

    val context = LocalContext.current
    var selectedAccount by remember(currentAccount) { mutableStateOf(currentAccount) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val currentRequest = remember(selectedAccount, amount, note) {
        QrPaymentRequest(selectedAccount, amount, note)
    }

    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isGenerating by remember { mutableStateOf(true) }

    LaunchedEffect(currentRequest) {
        isGenerating = true
        withContext(Dispatchers.Default) {
            val bmp = QrGenerator.generateQrBitmap(currentRequest.buildUpiUri(), 450)
            withContext(Dispatchers.Main) {
                qrBitmap = bmp
                isGenerating = false
            }
        }
    }

    val hasAmount = amount.trim() != "" && amount.trim() != "0"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f))
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            val isLandscape = maxWidth > maxHeight

            if (isLandscape) {
                // ==================== TABLET LANDSCAPE: 3-SECTION COCKPIT ====================
                val cardWidth = min(maxWidth * 0.94f, 880.dp)
                val cardHeight = min(maxHeight * 0.94f, 520.dp)
                val qrSize = min(cardHeight * 0.84f, 380.dp)

                Card(
                    modifier = Modifier
                        .width(cardWidth)
                        .height(cardHeight)
                        .shadow(24.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, palette.border)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. LEFT SECTION: ACTIONS (Download & Share)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Top Badge
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.surfaceVariant)
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "⚡ " + Strings.get("app_title", lang),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                            }

                            // Middle Description
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Rear Seat\nPassenger Scan",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = palette.textSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Action Buttons
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                        val success = QrGenerator.saveCardToGallery(context, currentRequest, cardBitmap)
                                        if (success) {
                                            val name = QrGenerator.getCardFileName(currentRequest)
                                            Toast.makeText(context, "${Strings.get("saved_success", lang)}\n$name", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.surfaceVariant,
                                        contentColor = palette.textPrimary
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(Strings.get("download_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { QrGenerator.shareQrCode(context, currentRequest) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.primary,
                                        contentColor = palette.onPrimary
                                    )
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(Strings.get("share_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // 2. CENTER SECTION: MASSIVE QR CODE (Nearly full height, 1-2 mm margin)
                        Column(
                            modifier = Modifier
                                .weight(1.8f)
                                .fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(qrSize)
                                    .shadow(8.dp, RoundedCornerShape(18.dp))
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(Color.White)
                                    .border(2.dp, palette.border, RoundedCornerShape(18.dp))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isGenerating || qrBitmap == null) {
                                    CircularProgressIndicator(color = palette.primary, modifier = Modifier.size(36.dp))
                                } else {
                                    Image(
                                        bitmap = qrBitmap!!.asImageBitmap(),
                                        contentDescription = "UPI QR Code",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SCAN WITH ANY UPI APP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textSecondary,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // 3. RIGHT SECTION (DRIVER'S SIDE): CONTROLS, CLOSE BUTTON, UPI & AMOUNT
                        Column(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.End
                        ) {
                            // Top Driver Bar with Close (X) button on the RIGHT!
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Driver View",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = palette.textSecondary
                                )
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(palette.surfaceVariant, CircleShape)
                                        .border(1.dp, palette.border, CircleShape)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close",
                                        tint = palette.textPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            // Middle: UPI Dropdown + Amount Card + Note
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // UPI Dropdown
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(palette.surfaceVariant)
                                            .clickable { dropdownExpanded = true }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = selectedAccount.name,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = palette.textPrimary
                                            )
                                            Text(
                                                text = selectedAccount.upiId,
                                                fontSize = 10.sp,
                                                color = palette.textSecondary
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = palette.primary
                                        )
                                    }

                                    DropdownMenu(
                                        expanded = dropdownExpanded,
                                        onDismissRequest = { dropdownExpanded = false },
                                        modifier = Modifier.background(palette.surface)
                                    ) {
                                        allAccounts.forEach { acc ->
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                                        Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                                    }
                                                },
                                                onClick = {
                                                    selectedAccount = acc
                                                    onAccountChange(acc)
                                                    dropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // Luxury Amount Card
                                if (hasAmount) {
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp)),
                                        colors = CardDefaults.cardColors(containerColor = palette.displayCardBackground)
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 10.dp, horizontal = 12.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = "AMOUNT",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = palette.displayCardCurrency
                                            )
                                            Text(
                                                text = "₹ $amount",
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = palette.displayCardAmount
                                            )
                                        }
                                    }
                                }

                                if (note.trim() != "") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(palette.surfaceVariant)
                                            .padding(vertical = 6.dp, horizontal = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "Note: $note",
                                            fontSize = 11.sp,
                                            color = palette.textSecondary,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }

                            // Bottom Hint
                            Text(
                                text = "Easy Driver Reach",
                                fontSize = 10.sp,
                                color = palette.textSecondary,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                    }
                }
            } else {
                // ==================== MOBILE PORTRAIT: 100% ORIGINAL UNTOUCHED VERTICAL LAYOUT ====================
                val qrBoxSize = min(maxWidth * 0.78f, 300.dp)

                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                        .shadow(24.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, palette.border)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top Bar with Close
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Strings.get("qr_popup_title", lang),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(palette.surfaceVariant, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = palette.textPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // UPI Selector Dropdown
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.surfaceVariant)
                                    .clickable { dropdownExpanded = true }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = selectedAccount.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = palette.textPrimary
                                    )
                                    Text(
                                        text = selectedAccount.upiId,
                                        fontSize = 11.sp,
                                        color = palette.textSecondary
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Switch UPI",
                                    tint = palette.primary
                                )
                            }

                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                allAccounts.forEach { acc ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                                Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                            }
                                        },
                                        onClick = {
                                            selectedAccount = acc
                                            onAccountChange(acc)
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (hasAmount) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹ $amount",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = palette.accent,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (note.trim() != "") {
                            Text(
                                text = "${Strings.get("notes", lang)} $note",
                                fontSize = 12.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // QR Box
                        Box(
                            modifier = Modifier
                                .size(qrBoxSize)
                                .shadow(6.dp, RoundedCornerShape(16.dp))
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .border(2.dp, palette.border, RoundedCornerShape(16.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isGenerating || qrBitmap == null) {
                                CircularProgressIndicator(color = palette.primary, modifier = Modifier.size(36.dp))
                            } else {
                                Image(
                                    bitmap = qrBitmap!!.asImageBitmap(),
                                    contentDescription = "UPI QR Code",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons: Download & Share
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                    val success = QrGenerator.saveCardToGallery(context, currentRequest, cardBitmap)
                                    if (success) {
                                        val name = QrGenerator.getCardFileName(currentRequest)
                                        Toast.makeText(context, "${Strings.get("saved_success", lang)}\n$name", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.surfaceVariant,
                                    contentColor = palette.textPrimary
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Download", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(Strings.get("download_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { QrGenerator.shareQrCode(context, currentRequest) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.primary,
                                    contentColor = palette.onPrimary
                                )
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(Strings.get("share_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
