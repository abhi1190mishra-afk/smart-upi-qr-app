package com.upiqr.generator.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.QrPaymentRequest
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.CustomPalette
import com.upiqr.generator.util.QrGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun QrPopupModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    amount: String,
    note: String,
    currentAccount: UpiAccount,
    allAccounts: List<UpiAccount>,
    onAccountChange: (UpiAccount) -> Unit,
    palette: CustomPalette,
    lang: AppLanguage
) {
    if (!isOpen) return

    val context = LocalContext.current
    var selectedAccount by remember(currentAccount) { mutableStateOf(currentAccount) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val currentRequest = remember(selectedAccount, amount, note) {
        QrPaymentRequest(selectedAccount, amount, note)
    }

    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isGenerating by remember { mutableStateOf(true) }

    LaunchedEffect(currentRequest) {
        isGenerating = true
        withContext(Dispatchers.Default) {
            val bmp = QrGenerator.generateQrBitmap(currentRequest.buildUpiUri(), 500)
            withContext(Dispatchers.Main) {
                qrBitmap = bmp
                isGenerating = false
            }
        }
    }

    val hasAmount = amount.trim() != "" && amount.trim() != "0"
    val hasNote = note.trim() != ""

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.90f))
                .padding(horizontal = 4.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            val isLandscape = maxWidth > maxHeight

            if (isLandscape) {
                // ==================== CAR TABLET: EDGE-TO-EDGE 97% FILL ====================
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.98f)
                        .fillMaxHeight(0.97f)
                        .shadow(28.dp, RoundedCornerShape(22.dp)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. LEFT COLUMN: CLEAN ACTION BUTTONS
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(0.94f),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                        val success = QrGenerator.saveCardToGallery(context, currentRequest, cardBitmap)
                                        if (success) {
                                            val name = QrGenerator.getCardFileName(currentRequest)
                                            Toast.makeText(context, "${Strings.get("saved_success", lang)}\n$name", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF1F5F9),
                                        contentColor = Color(0xFF0F172A)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1))
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF0F172A))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(Strings.get("download_qr", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { QrGenerator.shareQrCode(context, currentRequest) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2563EB),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(Strings.get("share_qr", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // 2. CENTER COLUMN: ATTRACTIVE MERCHANT NAME, MASSIVE FULL-HEIGHT QR, VIBRANT AMOUNT
                        Column(
                            modifier = Modifier
                                .weight(2.4f)
                                .fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top: High-Contrast Eye-Catching Emerald & Gold Merchant Badge!
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .shadow(4.dp, RoundedCornerShape(12.dp))
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF064E3B)) // Deep Emerald
                                    .border(1.5.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 20.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "★  ",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFFBBF24) // Gold Star
                                    )
                                    Text(
                                        text = selectedAccount.name,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            // Center: Massive QR Code filling maximum available height!
                            Box(
                                modifier = Modifier
                                    .weight(1f, fill = false)
                                    .fillMaxHeight(if (hasAmount || hasNote) 0.74f else 0.84f)
                                    .aspectRatio(1f)
                                    .shadow(6.dp, RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White)
                                    .border(2.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isGenerating || qrBitmap == null) {
                                    CircularProgressIndicator(color = Color(0xFF2563EB), modifier = Modifier.size(44.dp))
                                } else {
                                    Image(
                                        bitmap = qrBitmap!!.asImageBitmap(),
                                        contentDescription = "UPI QR Code",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            // Bottom: High-Contrast Vibrant Emerald Amount Card & Note (Visible from rear seat!)
                            if (hasAmount || hasNote) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    if (hasAmount) {
                                        Box(
                                            modifier = Modifier
                                                .shadow(4.dp, RoundedCornerShape(12.dp))
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color(0xFF059669))
                                                .border(1.dp, Color(0xFF34D399), RoundedCornerShape(12.dp))
                                                .padding(horizontal = 24.dp, vertical = 5.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "₹ ",
                                                    fontSize = 26.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = Color(0xFFFEF08A) // Gold ₹
                                                )
                                                Text(
                                                    text = amount,
                                                    fontSize = 26.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                    if (hasNote) {
                                        Text(
                                            text = "Note: $note",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF475569),
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // 3. RIGHT COLUMN (DRIVER SIDE): CLOSE (✕) AT TOP RIGHT & ACTIVE UPI SELECTOR
                        Column(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.End
                        ) {
                            // Close (✕) button at top right (driver hand reach!)
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .size(42.dp)
                                    .background(Color(0xFFF1F5F9), CircleShape)
                                    .border(1.dp, Color(0xFFCBD5E1), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color(0xFF0F172A),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Middle: UPI Dropdown
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFFF8FAFC))
                                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                                        .clickable { dropdownExpanded = true }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = selectedAccount.name,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = selectedAccount.upiId,
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = Color(0xFF2563EB)
                                    )
                                }

                                DropdownMenu(
                                    expanded = dropdownExpanded,
                                    onDismissRequest = { dropdownExpanded = false },
                                    modifier = Modifier.background(Color.White)
                                ) {
                                    allAccounts.forEach { acc ->
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(acc.name, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                                    Text(acc.upiId, fontSize = 11.sp, color = Color(0xFF64748B))
                                                }
                                            },
                                            onClick = {
                                                selectedAccount = acc
                                                onAccountChange(acc)
                                                dropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                }
            } else {
                // ==================== MOBILE PORTRAIT: UNTOUCHED VERTICAL LAYOUT ====================
                val qrBoxSize = min(maxWidth * 0.78f, 300.dp)

                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                        .shadow(24.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, palette.border)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top Bar with Close
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedAccount.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(palette.surfaceVariant, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = palette.textPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // UPI Selector Dropdown
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.surfaceVariant)
                                    .clickable { dropdownExpanded = true }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = selectedAccount.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = palette.textPrimary
                                    )
                                    Text(
                                        text = selectedAccount.upiId,
                                        fontSize = 11.sp,
                                        color = palette.textSecondary
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = palette.primary
                                )
                            }

                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                allAccounts.forEach { acc ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                                Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                            }
                                        },
                                        onClick = {
                                            selectedAccount = acc
                                            onAccountChange(acc)
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (hasAmount) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹ $amount",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = palette.accent,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (hasNote) {
                            Text(
                                text = "Note: $note",
                                fontSize = 12.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // QR Box
                        Box(
                            modifier = Modifier
                                .size(qrBoxSize)
                                .shadow(6.dp, RoundedCornerShape(16.dp))
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .border(2.dp, palette.border, RoundedCornerShape(16.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isGenerating || qrBitmap == null) {
                                CircularProgressIndicator(color = palette.primary, modifier = Modifier.size(36.dp))
                            } else {
                                Image(
                                    bitmap = qrBitmap!!.asImageBitmap(),
                                    contentDescription = "UPI QR Code",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons: Download & Share
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                    val success = QrGenerator.saveCardToGallery(context, currentRequest, cardBitmap)
                                    if (success) {
                                        val name = QrGenerator.getCardFileName(currentRequest)
                                        Toast.makeText(context, "${Strings.get("saved_success", lang)}\n$name", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.surfaceVariant,
                                    contentColor = palette.textPrimary
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Download", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(Strings.get("download_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { QrGenerator.shareQrCode(context, currentRequest) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.primary,
                                    contentColor = palette.onPrimary
                                )
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(Strings.get("share_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
