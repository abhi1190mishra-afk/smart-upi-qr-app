package com.upiqr.generator.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.QrPaymentRequest
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.CustomPalette
import com.upiqr.generator.util.QrGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun QrPopupModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    amount: String,
    note: String,
    currentAccount: UpiAccount,
    allAccounts: List<UpiAccount>,
    onAccountChange: (UpiAccount) -> Unit,
    palette: CustomPalette,
    lang: AppLanguage
) {
    if (!isOpen) return

    val context = LocalContext.current
    var selectedAccount by remember(currentAccount) { mutableStateOf(currentAccount) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val currentRequest = remember(selectedAccount, amount, note) {
        QrPaymentRequest(selectedAccount, amount, note)
    }

    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isGenerating by remember { mutableStateOf(true) }

    LaunchedEffect(currentRequest) {
        isGenerating = true
        withContext(Dispatchers.Default) {
            val bmp = QrGenerator.generateQrBitmap(currentRequest.buildUpiUri(), 450)
            withContext(Dispatchers.Main) {
                qrBitmap = bmp
                isGenerating = false
            }
        }
    }

    val hasAmount = amount.trim().isNotEmpty() && amount.trim() != "0"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            val isLandscape = maxWidth > maxHeight
            
            // In Car Tablet (Landscape), screen height is small, so QR is scaled to fit height
            // In Mobile (Portrait), QR is scaled to fit width
            val qrBoxSize = if (isLandscape) {
                min(maxHeight * 0.48f, 230.dp)
            } else {
                min(maxWidth * 0.78f, 300.dp)
            }

            val cardMaxWidth = if (isLandscape) {
                min(maxWidth * 0.60f, 460.dp)
            } else {
                maxWidth * 0.94f
            }

            Card(
                modifier = Modifier
                    .width(cardMaxWidth)
                    .wrapContentHeight()
                    .shadow(24.dp, RoundedCornerShape(22.dp)),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = palette.surface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, palette.border)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Bar with Close
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = Strings.get("qr_popup_title", lang),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(30.dp)
                                .background(palette.surfaceVariant, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = palette.textPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // UPI Selector Dropdown
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.surfaceVariant)
                                .clickable { dropdownExpanded = true }
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = selectedAccount.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = selectedAccount.upiId,
                                    fontSize = 11.sp,
                                    color = palette.textSecondary
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch UPI",
                                tint = palette.primary
                            )
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.background(palette.surface)
                        ) {
                            allAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                            Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                        }
                                    },
                                    onClick = {
                                        selectedAccount = acc
                                        onAccountChange(acc)
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (hasAmount) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹ $amount",
                            fontSize = if (isLandscape) 24.sp else 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.accent,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (note.trim().isNotEmpty()) {
                        Text(
                            text = "${Strings.get("notes", lang)} $note",
                            fontSize = 12.sp,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Responsive Square QR Container - 100% inside screen on both Tablet and Phone!
                    Box(
                        modifier = Modifier
                            .size(qrBoxSize)
                            .shadow(6.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(2.dp, palette.border, RoundedCornerShape(14.dp))
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isGenerating || qrBitmap == null) {
                            CircularProgressIndicator(color = palette.primary, modifier = Modifier.size(32.dp))
                        } else {
                            Image(
                                bitmap = qrBitmap!!.asImageBitmap(),
                                contentDescription = "UPI QR Code",
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Action Buttons: Download & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                val success = QrGenerator.saveCardToGallery(context, currentRequest, cardBitmap)
                                if (success) {
                                    val name = QrGenerator.getCardFileName(currentRequest)
                                    Toast.makeText(context, "${Strings.get("saved_success", lang)}\n$name", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error saving card", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.surfaceVariant,
                                contentColor = palette.textPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Download", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(Strings.get("download_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                QrGenerator.shareQrCode(context, currentRequest)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.primary,
                                contentColor = palette.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(Strings.get("share_qr", lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
