package com.upiqr.generator.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.QrPaymentRequest
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.CustomPalette
import com.upiqr.generator.util.QrGenerator

@Composable
fun QrPopupModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    amount: String,
    note: String,
    currentAccount: UpiAccount,
    allAccounts: List<UpiAccount>,
    onAccountChange: (UpiAccount) -> Unit,
    palette: CustomPalette,
    lang: AppLanguage
) {
    if (!isOpen) return

    val context = LocalContext.current
    var selectedAccount by remember(currentAccount) { mutableStateOf(currentAccount) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val currentRequest = remember(selectedAccount, amount, note) {
        QrPaymentRequest(selectedAccount, amount, note)
    }

    val qrBitmap = remember(currentRequest) {
        QrGenerator.generateQrBitmap(currentRequest.buildUpiUri(), 800)
    }

    val hasAmount = amount.trim().isNotEmpty() && amount.trim() != "0"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.background.copy(alpha = 0.96f))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .wrapContentHeight()
                    .shadow(24.dp, RoundedCornerShape(32.dp)),
                shape = RoundedCornerShape(32.dp),
                colors = CardDefaults.cardColors(containerColor = palette.surface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, palette.border)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Bar with Close
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = Strings.get("qr_popup_title", lang),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .background(palette.surfaceVariant, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = palette.textPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // UPI Selector Dropdown inside Popup
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.surfaceVariant)
                                .clickable { dropdownExpanded = true }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = selectedAccount.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = selectedAccount.upiId,
                                    fontSize = 12.sp,
                                    color = palette.textSecondary
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch UPI",
                                tint = palette.primary
                            )
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.background(palette.surface)
                        ) {
                            allAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.name, fontWeight = FontWeight.SemiBold, color = palette.textPrimary)
                                            Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                        }
                                    },
                                    onClick = {
                                        selectedAccount = acc
                                        onAccountChange(acc)
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (hasAmount) {
                        Text(
                            text = "₹ $amount",
                            fontSize = 38.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.accent,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (note.trim().isNotEmpty()) {
                        Text(
                            text = "${Strings.get("notes", lang)} $note",
                            fontSize = 13.sp,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // QR Code Image in Premium Card Container
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .shadow(8.dp, RoundedCornerShape(24.dp))
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.White)
                            .border(2.dp, palette.border, RoundedCornerShape(24.dp))
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "UPI QR Code",
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action Buttons: Download & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                val cardBitmap = QrGenerator.createBrandedQrCard(currentRequest)
                                val success = QrGenerator.saveCardToGallery(context, cardBitmap)
                                if (success) {
                                    Toast.makeText(context, Strings.get("saved_success", lang), Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error saving card", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.surfaceVariant,
                                contentColor = palette.textPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Download", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(Strings.get("download_qr", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                QrGenerator.shareQrCode(context, currentRequest)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.primary,
                                contentColor = palette.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(Strings.get("share_qr", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
