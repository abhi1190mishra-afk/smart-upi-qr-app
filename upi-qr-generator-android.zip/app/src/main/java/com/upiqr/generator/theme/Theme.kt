package com.upiqr.generator.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val title: String) {
    LIGHT("Light"),
    DARK("Dark"),
    AUTO("Auto (System)"),
    ROYAL_GOLD("Royal Gold"),
    AMOLED_BLACK("AMOLED Pitch Black"),
    EMERALD_GREEN("Emerald Green")
}

// Consistent Theme Palette Data
data class CustomPalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val primary: Color,
    val onPrimary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val keyBackground: Color,
    val keyText: Color,
    val keyActionBackground: Color,
    val keyActionText: Color,
    val border: Color,
    val accent: Color
)

val LightPalette = CustomPalette(
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFF1F5F9),
    primary = Color(0xFF0F172A),
    onPrimary = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    keyBackground = Color(0xFFFFFFFF),
    keyText = Color(0xFF0F172A),
    keyActionBackground = Color(0xFFE2E8F0),
    keyActionText = Color(0xFF0F172A),
    border = Color(0xFFE2E8F0),
    accent = Color(0xFF2563EB)
)

val DarkPalette = CustomPalette(
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFF334155),
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF0F172A),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    keyBackground = Color(0xFF1E293B),
    keyText = Color(0xFFF8FAFC),
    keyActionBackground = Color(0xFF334155),
    keyActionText = Color(0xFF38BDF8),
    border = Color(0xFF334155),
    accent = Color(0xFF38BDF8)
)

val AmoledPalette = CustomPalette(
    background = Color(0xFF000000),
    surface = Color(0xFF0A0A0A),
    surfaceVariant = Color(0xFF171717),
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF000000),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA3A3A3),
    keyBackground = Color(0xFF121212),
    keyText = Color(0xFFFFFFFF),
    keyActionBackground = Color(0xFF262626),
    keyActionText = Color(0xFFFFFFFF),
    border = Color(0xFF262626),
    accent = Color(0xFFFFFFFF)
)

val RoyalGoldPalette = CustomPalette(
    background = Color(0xFF0A0E17),
    surface = Color(0xFF131B2E),
    surfaceVariant = Color(0xFF1C2742),
    primary = Color(0xFFD4AF37),
    onPrimary = Color(0xFF0A0E17),
    textPrimary = Color(0xFFF1F5F9),
    textSecondary = Color(0xFF94A3B8),
    keyBackground = Color(0xFF131B2E),
    keyText = Color(0xFFF8FAFC),
    keyActionBackground = Color(0xFF1C2742),
    keyActionText = Color(0xFFD4AF37),
    border = Color(0xFF2B3A5E),
    accent = Color(0xFFD4AF37)
)

val EmeraldPalette = CustomPalette(
    background = Color(0xFF062018),
    surface = Color(0xFF0B2F24),
    surfaceVariant = Color(0xFF124435),
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF062018),
    textPrimary = Color(0xFFECFDF5),
    textSecondary = Color(0xFF6EE7B7),
    keyBackground = Color(0xFF0B2F24),
    keyText = Color(0xFFECFDF5),
    keyActionBackground = Color(0xFF124435),
    keyActionText = Color(0xFF10B981),
    border = Color(0xFF1F5E4B),
    accent = Color(0xFF34D399)
)

fun getPalette(mode: AppThemeMode, isSystemDark: Boolean): CustomPalette {
    return when (mode) {
        AppThemeMode.LIGHT -> LightPalette
        AppThemeMode.DARK -> DarkPalette
        AppThemeMode.AUTO -> if (isSystemDark) DarkPalette else LightPalette
        AppThemeMode.ROYAL_GOLD -> RoyalGoldPalette
        AppThemeMode.AMOLED_BLACK -> AmoledPalette
        AppThemeMode.EMERALD_GREEN -> EmeraldPalette
    }
}
