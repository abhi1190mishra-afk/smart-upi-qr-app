package com.upiqr.generator.theme

import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val title: String) {
    LIGHT("Light"),
    DARK("Dark"),
    AUTO("Auto (System)"),
    ROYAL_GOLD("Royal Gold"),
    AMOLED_BLACK("AMOLED Pitch Black"),
    EMERALD_GREEN("Emerald Green")
}

data class CustomPalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val displayCardBackground: Color,
    val displayCardCurrency: Color,
    val displayCardAmount: Color,
    val primary: Color,
    val onPrimary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val keyDeckBackground: Color,
    val keyBackground: Color,
    val keyText: Color,
    val keyOperatorBackground: Color,
    val keyOperatorText: Color,
    val keyClearBackground: Color,
    val keyClearText: Color,
    val border: Color,
    val accent: Color
)

// Vibrant Luxury Light Palette (Indigo, Amber Gold, Emerald CTA - No ugly black block!)
val LightPalette = CustomPalette(
    background = Color(0xFFF1F5F9),           // Soft snow slate
    surface = Color(0xFFFFFFFF),              // Pure white cards
    surfaceVariant = Color(0xFFE2E8F0),       // Clean accent surface
    displayCardBackground = Color(0xFF1E293B), // Deep Sapphire Slate Card
    displayCardCurrency = Color(0xFFF59E0B),   // Warm Amber Gold ₹ symbol
    displayCardAmount = Color(0xFFFFFFFF),     // Crisp white amount numbers
    primary = Color(0xFF059669),              // Vibrant Emerald Green CTA
    onPrimary = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    keyDeckBackground = Color(0xFFE2E8F0),    // Sculpted Keypad Tray
    keyBackground = Color(0xFFFFFFFF),        // Clean white number buttons
    keyText = Color(0xFF0F172A),              // High-contrast numbers
    keyOperatorBackground = Color(0xFFF59E0B),// Rich Amber Operator (+, -, ×, ÷, =)
    keyOperatorText = Color(0xFFFFFFFF),
    keyClearBackground = Color(0xFFE2E8F0),   // Soft Coral/Muted (C, ⌫, %)
    keyClearText = Color(0xFFDC2626),         // Vibrant Red accent for clear
    border = Color(0xFFCBD5E1),
    accent = Color(0xFF2563EB)
)

val DarkPalette = CustomPalette(
    background = Color(0xFF0B1120),
    surface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFF334155),
    displayCardBackground = Color(0xFF131D31),
    displayCardCurrency = Color(0xFF38BDF8),
    displayCardAmount = Color(0xFFF8FAFC),
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF0B1120),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    keyDeckBackground = Color(0xFF0F172A),
    keyBackground = Color(0xFF1E293B),
    keyText = Color(0xFFF8FAFC),
    keyOperatorBackground = Color(0xFFF59E0B),
    keyOperatorText = Color(0xFFFFFFFF),
    keyClearBackground = Color(0xFF334155),
    keyClearText = Color(0xFFF87171),
    border = Color(0xFF334155),
    accent = Color(0xFF38BDF8)
)

val AmoledPalette = CustomPalette(
    background = Color(0xFF000000),
    surface = Color(0xFF0D0D0D),
    surfaceVariant = Color(0xFF1A1A1A),
    displayCardBackground = Color(0xFF111111),
    displayCardCurrency = Color(0xFFF59E0B),
    displayCardAmount = Color(0xFFFFFFFF),
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF000000),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA3A3A3),
    keyDeckBackground = Color(0xFF050505),
    keyBackground = Color(0xFF141414),
    keyText = Color(0xFFFFFFFF),
    keyOperatorBackground = Color(0xFFF59E0B),
    keyOperatorText = Color(0xFF000000),
    keyClearBackground = Color(0xFF262626),
    keyClearText = Color(0xFFEF4444),
    border = Color(0xFF262626),
    accent = Color(0xFFFFFFFF)
)

val RoyalGoldPalette = CustomPalette(
    background = Color(0xFF070B14),
    surface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFF1E293B),
    displayCardBackground = Color(0xFF131B2E),
    displayCardCurrency = Color(0xFFF59E0B),
    displayCardAmount = Color(0xFFF8FAFC),
    primary = Color(0xFFD97706),
    onPrimary = Color(0xFF070B14),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    keyDeckBackground = Color(0xFF0B1222),
    keyBackground = Color(0xFF131D31),
    keyText = Color(0xFFF8FAFC),
    keyOperatorBackground = Color(0xFFD97706),
    keyOperatorText = Color(0xFFFFFFFF),
    keyClearBackground = Color(0xFF1E2D4A),
    keyClearText = Color(0xFFF87171),
    border = Color(0xFF1E293B),
    accent = Color(0xFFF59E0B)
)

val EmeraldPalette = CustomPalette(
    background = Color(0xFF021710),
    surface = Color(0xFF062B1E),
    surfaceVariant = Color(0xFF0D3E2C),
    displayCardBackground = Color(0xFF063B29),
    displayCardCurrency = Color(0xFF34D399),
    displayCardAmount = Color(0xFFECFDF5),
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF021710),
    textPrimary = Color(0xFFECFDF5),
    textSecondary = Color(0xFF6EE7B7),
    keyDeckBackground = Color(0xFF041E15),
    keyBackground = Color(0xFF083324),
    keyText = Color(0xFFECFDF5),
    keyOperatorBackground = Color(0xFF10B981),
    keyOperatorText = Color(0xFF021710),
    keyClearBackground = Color(0xFF0E4532),
    keyClearText = Color(0xFFF87171),
    border = Color(0xFF134E39),
    accent = Color(0xFF34D399)
)

fun getPalette(mode: AppThemeMode, isSystemDark: Boolean): CustomPalette {
    return when (mode) {
        AppThemeMode.LIGHT -> LightPalette
        AppThemeMode.DARK -> DarkPalette
        AppThemeMode.AUTO -> if (isSystemDark) DarkPalette else LightPalette
        AppThemeMode.ROYAL_GOLD -> RoyalGoldPalette
        AppThemeMode.AMOLED_BLACK -> AmoledPalette
        AppThemeMode.EMERALD_GREEN -> EmeraldPalette
    }
}
