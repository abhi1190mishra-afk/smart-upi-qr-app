package com.upiqr.generator.theme

import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val title: String) {
    LIGHT("Light"),
    DARK("Dark"),
    AUTO("Auto (System)"),
    ROYAL_GOLD("Royal Gold"),
    AMOLED_BLACK("AMOLED Pitch Black"),
    EMERALD_GREEN("Emerald Green")
}

data class CustomPalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val displayCardBackground: Color,
    val displayCardText: Color,
    val primary: Color,
    val onPrimary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val keyDeckBackground: Color,
    val keyBackground: Color,
    val keyText: Color,
    val keyActionBackground: Color,
    val keyActionText: Color,
    val border: Color,
    val accent: Color
)

// Premium Light Theme: Slate & Crisp contrast (Eliminates flat white-on-white)
val LightPalette = CustomPalette(
    background = Color(0xFFF1F5F9),          // Soft slate grey background
    surface = Color(0xFFFFFFFF),             // Pure white cards
    surfaceVariant = Color(0xFFE2E8F0),      // Distinct muted surface
    displayCardBackground = Color(0xFF0F172A),// Deep Obsidian Amount Display
    displayCardText = Color(0xFF38BDF8),     // Electric cyan amount
    primary = Color(0xFF0F172A),             // Midnight slate CTA button
    onPrimary = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    keyDeckBackground = Color(0xFFE2E8F0),   // Sculpted Keypad Tray
    keyBackground = Color(0xFFFFFFFF),       // Crisp white keys
    keyText = Color(0xFF0F172A),             // Deep bold key text
    keyActionBackground = Color(0xFFCBD5E1), // Tactile action keys (+, -, C, del)
    keyActionText = Color(0xFF0F172A),
    border = Color(0xFFCBD5E1),              // Visible clean borders
    accent = Color(0xFF2563EB)
)

val DarkPalette = CustomPalette(
    background = Color(0xFF0B1120),
    surface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFF334155),
    displayCardBackground = Color(0xFF020617),
    displayCardText = Color(0xFF38BDF8),
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF0B1120),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    keyDeckBackground = Color(0xFF0F172A),
    keyBackground = Color(0xFF1E293B),
    keyText = Color(0xFFF8FAFC),
    keyActionBackground = Color(0xFF334155),
    keyActionText = Color(0xFF38BDF8),
    border = Color(0xFF334155),
    accent = Color(0xFF38BDF8)
)

val AmoledPalette = CustomPalette(
    background = Color(0xFF000000),
    surface = Color(0xFF0D0D0D),
    surfaceVariant = Color(0xFF1A1A1A),
    displayCardBackground = Color(0xFF080808),
    displayCardText = Color(0xFFFFFFFF),
    primary = Color(0xFFFFFFFF),
    onPrimary = Color(0xFF000000),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA3A3A3),
    keyDeckBackground = Color(0xFF050505),
    keyBackground = Color(0xFF141414),
    keyText = Color(0xFFFFFFFF),
    keyActionBackground = Color(0xFF262626),
    keyActionText = Color(0xFFFFFFFF),
    border = Color(0xFF262626),
    accent = Color(0xFFFFFFFF)
)

val RoyalGoldPalette = CustomPalette(
    background = Color(0xFF070B14),
    surface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFF1E293B),
    displayCardBackground = Color(0xFF0A0F1D),
    displayCardText = Color(0xFFF59E0B),
    primary = Color(0xFFD97706),
    onPrimary = Color(0xFF070B14),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    keyDeckBackground = Color(0xFF0B1222),
    keyBackground = Color(0xFF131D31),
    keyText = Color(0xFFF8FAFC),
    keyActionBackground = Color(0xFF1E2D4A),
    keyActionText = Color(0xFFF59E0B),
    border = Color(0xFF1E293B),
    accent = Color(0xFFF59E0B)
)

val EmeraldPalette = CustomPalette(
    background = Color(0xFF021710),
    surface = Color(0xFF062B1E),
    surfaceVariant = Color(0xFF0D3E2C),
    displayCardBackground = Color(0xFF01140E),
    displayCardText = Color(0xFF34D399),
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF021710),
    textPrimary = Color(0xFFECFDF5),
    textSecondary = Color(0xFF6EE7B7),
    keyDeckBackground = Color(0xFF041E15),
    keyBackground = Color(0xFF083324),
    keyText = Color(0xFFECFDF5),
    keyActionBackground = Color(0xFF0E4532),
    keyActionText = Color(0xFF34D399),
    border = Color(0xFF134E39),
    accent = Color(0xFF34D399)
)

fun getPalette(mode: AppThemeMode, isSystemDark: Boolean): CustomPalette {
    return when (mode) {
        AppThemeMode.LIGHT -> LightPalette
        AppThemeMode.DARK -> DarkPalette
        AppThemeMode.AUTO -> if (isSystemDark) DarkPalette else LightPalette
        AppThemeMode.ROYAL_GOLD -> RoyalGoldPalette
        AppThemeMode.AMOLED_BLACK -> AmoledPalette
        AppThemeMode.EMERALD_GREEN -> EmeraldPalette
    }
}
