package com.upiqr.generator.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.AppThemeMode
import com.upiqr.generator.theme.CustomPalette

@Composable
fun HomeScreen(
    palette: CustomPalette,
    themeMode: AppThemeMode,
    onThemeChange: (AppThemeMode) -> Unit,
    language: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit
) {
    var noteText by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var showQrPopup by remember { mutableStateOf(false) }
    var showAddUpiDialog by remember { mutableStateOf(false) }

    var upiAccounts by remember {
        mutableStateOf(
            listOf(
                UpiAccount("1", "Main Store", "merchant@upi", isDefault = true),
                UpiAccount("2", "Paytm Business", "9876543210@paytm"),
                UpiAccount("3", "HDFC UPI", "shop@hdfcbank")
            )
        )
    }
    var selectedAccount by remember { mutableStateOf(upiAccounts.first()) }

    var langMenuExpanded by remember { mutableStateOf(false) }
    var themeMenuExpanded by remember { mutableStateOf(false) }
    var upiMenuExpanded by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    fun handleKeyPress(key: String) {
        when (key) {
            "C" -> amountText = ""
            "⌫" -> if (amountText.isNotEmpty()) amountText = amountText.dropLast(1)
            "." -> if (!amountText.contains(".")) amountText = if (amountText.isEmpty()) "0." else "$amountText."
            "00" -> if (amountText.isNotEmpty()) amountText += "00"
            "+", "-" -> {}
            else -> {
                if (amountText.length < 9) {
                    amountText += key
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo + Title
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = palette.onPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = Strings.get("app_title", language),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                    }

                    // Action Icons: Language + Theme
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Language Chip Button
                        Box {
                            IconButton(
                                onClick = { langMenuExpanded = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Text(
                                    text = "文A",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                            }
                            DropdownMenu(
                                expanded = langMenuExpanded,
                                onDismissRequest = { langMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppLanguage.values().forEach { lang ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                lang.displayName,
                                                fontWeight = if (lang == language) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onLanguageChange(lang)
                                            langMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Theme Button
                        Box {
                            IconButton(
                                onClick = { themeMenuExpanded = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Theme",
                                    tint = palette.accent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = themeMenuExpanded,
                                onDismissRequest = { themeMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppThemeMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                mode.title,
                                                fontWeight = if (mode == themeMode) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onThemeChange(mode)
                                            themeMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Compact Saved UPI Selector + Add Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.surface)
                                .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                                .clickable { upiMenuExpanded = true }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = selectedAccount.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = selectedAccount.upiId,
                                    fontSize = 11.sp,
                                    color = palette.textSecondary
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = palette.primary)
                        }

                        DropdownMenu(
                            expanded = upiMenuExpanded,
                            onDismissRequest = { upiMenuExpanded = false },
                            modifier = Modifier.background(palette.surface)
                        ) {
                            upiAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                            Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                        }
                                    },
                                    onClick = {
                                        selectedAccount = acc
                                        upiMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { showAddUpiDialog = true },
                        modifier = Modifier
                            .size(38.dp)
                            .background(palette.surfaceVariant, RoundedCornerShape(10.dp))
                            .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add UPI", tint = palette.primary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Notes Field
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    placeholder = {
                        Text(
                            Strings.get("notes_placeholder", language),
                            fontSize = 12.sp,
                            color = palette.textSecondary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = palette.surface,
                        unfocusedContainerColor = palette.surface,
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() }
                    ),
                    trailingIcon = {
                        if (noteText.isNotEmpty()) {
                            IconButton(onClick = { noteText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Amount Display Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, if (amountText.isNotEmpty()) palette.accent else palette.border)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "₹",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.accent
                        )
                        Text(
                            text = if (amountText.isEmpty()) "0" else amountText,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (amountText.isEmpty()) palette.textSecondary.copy(alpha = 0.5f) else palette.textPrimary,
                            textAlign = TextAlign.End
                        )
                    }
                }
            }

            // Bottom Section: Keypad + Generate Button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 10.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CalculatorKeypad(
                    modifier = Modifier.weight(1f),
                    palette = palette,
                    onKeyPress = { handleKeyPress(it) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { showQrPopup = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .shadow(12.dp, RoundedCornerShape(18.dp)),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.primary,
                        contentColor = palette.onPrimary
                    )
                ) {
                    Text(
                        text = "⚡  " + Strings.get("generate_qr", language),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }

        QrPopupModal(
            isOpen = showQrPopup,
            onDismiss = { showQrPopup = false },
            amount = amountText,
            note = noteText,
            currentAccount = selectedAccount,
            allAccounts = upiAccounts,
            onAccountChange = { selectedAccount = it },
            palette = palette,
            lang = language
        )

        if (showAddUpiDialog) {
            var newName by remember { mutableStateOf("") }
            var newUpiId by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddUpiDialog = false },
                containerColor = palette.surface,
                title = {
                    Text(
                        Strings.get("add_new_upi", language),
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text(Strings.get("merchant_name", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = newUpiId,
                            onValueChange = { newUpiId = it },
                            label = { Text("UPI ID") },
                            placeholder = { Text(Strings.get("upi_id_hint", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank() && newUpiId.isNotBlank()) {
                                val acc = UpiAccount(
                                    id = System.currentTimeMillis().toString(),
                                    name = newName.trim(),
                                    upiId = newUpiId.trim()
                                )
                                upiAccounts = upiAccounts + acc
                                selectedAccount = acc
                                showAddUpiDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary)
                    ) {
                        Text(Strings.get("save", language), color = palette.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddUpiDialog = false }) {
                        Text(Strings.get("cancel", language), color = palette.textSecondary)
                    }
                }
            )
        }
    }
}
