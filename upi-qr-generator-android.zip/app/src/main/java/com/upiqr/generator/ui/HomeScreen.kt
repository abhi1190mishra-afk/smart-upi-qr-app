package com.upiqr.generator.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.AppThemeMode
import com.upiqr.generator.theme.CustomPalette

@Composable
fun HomeScreen(
    palette: CustomPalette,
    themeMode: AppThemeMode,
    onThemeChange: (AppThemeMode) -> Unit,
    language: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("upi_qr_prefs", Context.MODE_PRIVATE) }

    var noteText by remember { mutableStateOf("") }
    var expressionText by remember { mutableStateOf("") }
    var showQrPopup by remember { mutableStateOf(false) }
    var showAddUpiDialog by remember { mutableStateOf(false) }

    // Persistent Accounts
    var upiAccounts by remember {
        val savedJson = prefs.getString("saved_accounts", null)
        mutableStateOf(if (savedJson != null) UpiAccount.listFromJson(savedJson) else UpiAccount.defaultAccounts())
    }

    // Persistent Active Account
    var selectedAccountId by remember {
        mutableStateOf(prefs.getString("selected_account_id", upiAccounts.firstOrNull()?.id ?: "1") ?: "1")
    }

    val selectedAccount = upiAccounts.firstOrNull { it.id == selectedAccountId } ?: upiAccounts.firstOrNull() ?: UpiAccount("1", "Store", "upi@bank")

    fun saveAccounts(list: List<UpiAccount>, activeId: String) {
        upiAccounts = list
        selectedAccountId = activeId
        prefs.edit()
            .putString("saved_accounts", UpiAccount.listToJson(list))
            .putString("selected_account_id", activeId)
            .apply()
    }

    var langMenuExpanded by remember { mutableStateOf(false) }
    var themeMenuExpanded by remember { mutableStateOf(false) }
    var upiMenuExpanded by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    // Live Calculator Evaluation Engine
    fun evaluateExpression(expr: String): String {
        return try {
            val clean = expr.replace("×", "*").replace("÷", "/")
            if (clean.endsWith("+") || clean.endsWith("-") || clean.endsWith("*") || clean.endsWith("/")) {
                clean.dropLast(1)
            } else if (clean.contains("%")) {
                val parts = clean.split("%")
                val base = parts[0].toDoubleOrNull() ?: 0.0
                (base / 100.0).toString()
            } else {
                // simple 2-operand or single operand eval
                val ops = listOf("+", "-", "*", "/")
                var foundOp = ""
                for (op in ops) {
                    if (clean.contains(op) && !clean.startsWith(op)) {
                        foundOp = op
                        break
                    }
                }
                if (foundOp.isNotEmpty()) {
                    val tokens = clean.split(foundOp)
                    if (tokens.size == 2) {
                        val num1 = tokens[0].toDoubleOrNull() ?: 0.0
                        val num2 = tokens[1].toDoubleOrNull() ?: 0.0
                        val result = when (foundOp) {
                            "+" -> num1 + num2
                            "-" -> num1 - num2
                            "*" -> num1 * num2
                            "/" -> if (num2 != 0.0) num1 / num2 else 0.0
                            else -> num1
                        }
                        if (result % 1.0 == 0.0) result.toLong().toString() else "%.2f".format(result)
                    } else clean
                } else clean
            }
        } catch (_: Exception) {
            expr
        }
    }

    fun handleKeyPress(key: String) {
        when (key) {
            "C" -> expressionText = ""
            "⌫" -> if (expressionText.isNotEmpty()) expressionText = expressionText.dropLast(1)
            "=" -> {
                if (expressionText.isNotEmpty()) {
                    expressionText = evaluateExpression(expressionText)
                }
            }
            "%" -> {
                if (expressionText.isNotEmpty() && !expressionText.endsWith("%")) {
                    val num = expressionText.toDoubleOrNull()
                    if (num != null) {
                        val res = num / 100.0
                        expressionText = if (res % 1.0 == 0.0) res.toLong().toString() else "%.2f".format(res)
                    }
                }
            }
            "+", "-", "×", "÷" -> {
                if (expressionText.isNotEmpty()) {
                    val lastChar = expressionText.last().toString()
                    if (lastChar in listOf("+", "-", "×", "÷")) {
                        expressionText = expressionText.dropLast(1) + key
                    } else {
                        // If already has an operator, evaluate first then append
                        expressionText = evaluateExpression(expressionText) + key
                    }
                }
            }
            "." -> {
                if (!expressionText.endsWith(".")) {
                    expressionText = if (expressionText.isEmpty()) "0." else expressionText + "."
                }
            }
            else -> {
                if (expressionText.length < 15) {
                    expressionText += key
                }
            }
        }
    }

    val finalAmount = remember(expressionText) {
        try {
            val eval = evaluateExpression(expressionText)
            eval.toDoubleOrNull()?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else "%.2f".format(it)
            } ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP SECTION: Header + Settings + Notes + Luxury Amount Card
            Column(modifier = Modifier.fillMaxWidth()) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .shadow(4.dp, RoundedCornerShape(10.dp))
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = palette.onPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = Strings.get("app_title", language),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                    }

                    // Action Icons: Language + Theme
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box {
                            IconButton(
                                onClick = { langMenuExpanded = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .shadow(2.dp, CircleShape)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Text(
                                    text = "文A",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                            }
                            DropdownMenu(
                                expanded = langMenuExpanded,
                                onDismissRequest = { langMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppLanguage.values().forEach { lang ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                lang.displayName,
                                                fontWeight = if (lang == language) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onLanguageChange(lang)
                                            langMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Box {
                            IconButton(
                                onClick = { themeMenuExpanded = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .shadow(2.dp, CircleShape)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Theme",
                                    tint = palette.accent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = themeMenuExpanded,
                                onDismissRequest = { themeMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppThemeMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                mode.title,
                                                fontWeight = if (mode == themeMode) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onThemeChange(mode)
                                            themeMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // UPI Selector + Add Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(2.dp, RoundedCornerShape(12.dp))
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.surface)
                                .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                                .clickable { upiMenuExpanded = true }
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = selectedAccount.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = selectedAccount.upiId,
                                    fontSize = 11.sp,
                                    color = palette.textSecondary
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = palette.primary)
                        }

                        DropdownMenu(
                            expanded = upiMenuExpanded,
                            onDismissRequest = { upiMenuExpanded = false },
                            modifier = Modifier.background(palette.surface)
                        ) {
                            upiAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                                Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                            }
                                            if (upiAccounts.size > 1) {
                                                IconButton(
                                                    onClick = {
                                                        val remaining = upiAccounts.filter { it.id != acc.id }
                                                        val nextActive = if (selectedAccountId == acc.id) remaining.first().id else selectedAccountId
                                                        saveAccounts(remaining, nextActive)
                                                        Toast.makeText(context, "Account deleted", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    },
                                    onClick = {
                                        saveAccounts(upiAccounts, acc.id)
                                        upiMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { showAddUpiDialog = true },
                        modifier = Modifier
                            .size(36.dp)
                            .shadow(2.dp, RoundedCornerShape(10.dp))
                            .background(palette.surfaceVariant, RoundedCornerShape(10.dp))
                            .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add UPI", tint = palette.primary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Notes Field
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    placeholder = {
                        Text(
                            Strings.get("notes_placeholder", language),
                            fontSize = 12.sp,
                            color = palette.textSecondary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = palette.surface,
                        unfocusedContainerColor = palette.surface,
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() }
                    ),
                    trailingIcon = {
                        if (noteText.isNotEmpty()) {
                            IconButton(onClick = { noteText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Rich Contrast Luxury Sapphire/Emerald Amount Display Card (No ugly black block!)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .shadow(4.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.displayCardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "₹",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.displayCardCurrency
                        )
                        Text(
                            text = if (expressionText.isEmpty()) "0" else expressionText,
                            fontSize = if (expressionText.length > 8) 26.sp else 34.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.displayCardAmount,
                            textAlign = TextAlign.End
                        )
                    }
                }
            }

            // BOTTOM SECTION: Full 5-Row Keypad (~50% height) + Generate Button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Wide Keypad Tray
                CalculatorKeypad(
                    modifier = Modifier.weight(1f),
                    palette = palette,
                    onKeyPress = { handleKeyPress(it) }
                )

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = { showQrPopup = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .shadow(8.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.primary,
                        contentColor = palette.onPrimary
                    )
                ) {
                    Text(
                        text = "⚡  " + Strings.get("generate_qr", language),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }

        // Full Screen Popup QR Modal
        QrPopupModal(
            isOpen = showQrPopup,
            onDismiss = { showQrPopup = false },
            amount = finalAmount,
            note = noteText,
            currentAccount = selectedAccount,
            allAccounts = upiAccounts,
            onAccountChange = { saveAccounts(upiAccounts, it.id) },
            palette = palette,
            lang = language
        )

        // Add UPI Dialog
        if (showAddUpiDialog) {
            var newName by remember { mutableStateOf("") }
            var newUpiId by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddUpiDialog = false },
                containerColor = palette.surface,
                title = {
                    Text(
                        Strings.get("add_new_upi", language),
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text(Strings.get("merchant_name", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = newUpiId,
                            onValueChange = { newUpiId = it },
                            label = { Text("UPI ID") },
                            placeholder = { Text(Strings.get("upi_id_hint", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank() && newUpiId.isNotBlank()) {
                                val acc = UpiAccount(
                                    id = System.currentTimeMillis().toString(),
                                    name = newName.trim(),
                                    upiId = newUpiId.trim()
                                )
                                val updated = upiAccounts + acc
                                saveAccounts(updated, acc.id)
                                showAddUpiDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary)
                    ) {
                        Text(Strings.get("save", language), color = palette.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddUpiDialog = false }) {
                        Text(Strings.get("cancel", language), color = palette.textSecondary)
                    }
                }
            )
        }
    }
}
