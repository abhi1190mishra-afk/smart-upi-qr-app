package com.upiqr.generator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.upiqr.generator.localization.AppLanguage
import com.upiqr.generator.localization.Strings
import com.upiqr.generator.model.UpiAccount
import com.upiqr.generator.theme.AppThemeMode
import com.upiqr.generator.theme.CustomPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(
    palette: CustomPalette,
    themeMode: AppThemeMode,
    onThemeChange: (AppThemeMode) -> Unit,
    language: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("upi_qr_prefs", Context.MODE_PRIVATE) }

    var noteText by remember { mutableStateOf("") }
    var expressionText by remember { mutableStateOf("") }
    var showQrPopup by remember { mutableStateOf(false) }
    var showAddUpiDialog by remember { mutableStateOf(false) }
    var accountToEdit by remember { mutableStateOf<UpiAccount?>(null) }

    // Scanned Add Account Dialog state
    var showScannedDialog by remember { mutableStateOf(false) }
    var scannedName by remember { mutableStateOf("") }
    var scannedUpiId by remember { mutableStateOf("") }

    // Persistent Accounts
    var upiAccounts by remember {
        val savedJson = prefs.getString("saved_accounts", null)
        mutableStateOf(if (savedJson != null) UpiAccount.listFromJson(savedJson) else UpiAccount.defaultAccounts())
    }

    var selectedAccountId by remember {
        mutableStateOf(prefs.getString("selected_account_id", upiAccounts.firstOrNull()?.id ?: "1") ?: "1")
    }

    val selectedAccount = upiAccounts.firstOrNull { it.id == selectedAccountId } ?: upiAccounts.firstOrNull() ?: UpiAccount("1", "Store", "upi@bank")

    fun saveAccounts(list: List<UpiAccount>, activeId: String) {
        upiAccounts = list
        selectedAccountId = activeId
        prefs.edit()
            .putString("saved_accounts", UpiAccount.listToJson(list))
            .putString("selected_account_id", activeId)
            .apply()
    }

    // Gallery QR Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.Default) {
                val decodedText = decodeQrFromUri(context, uri)
                withContext(Dispatchers.Main) {
                    if (!decodedText.isNullOrEmpty()) {
                        val upiDetails = parseUpiDetails(decodedText)
                        val name = upiDetails.first
                        val upiId = upiDetails.second
                        if (upiId != "") {
                            // 1. Auto-copy UPI ID to clipboard
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("UPI ID", upiId)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "UPI ID Copied: $upiId", Toast.LENGTH_SHORT).show()

                            // 2. Open Add to Account Dialog
                            scannedName = name
                            scannedUpiId = upiId
                            showScannedDialog = true
                        } else {
                            Toast.makeText(context, "No UPI ID found in QR code", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Could not scan QR from image", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    var langMenuExpanded by remember { mutableStateOf(false) }
    var themeMenuExpanded by remember { mutableStateOf(false) }
    var upiMenuExpanded by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    fun evaluateExpression(expr: String): String {
        return try {
            val clean = expr.replace("×", "*").replace("÷", "/")
            if (clean.endsWith("+") || clean.endsWith("-") || clean.endsWith("*") || clean.endsWith("/")) {
                clean.dropLast(1)
            } else if (clean.contains("%")) {
                val parts = clean.split("%")
                val base = parts[0].toDoubleOrNull() ?: 0.0
                (base / 100.0).toString()
            } else {
                val ops = listOf("+", "-", "*", "/")
                var foundOp = ""
                for (op in ops) {
                    if (clean.contains(op) && !clean.startsWith(op)) {
                        foundOp = op
                        break
                    }
                }
                if (foundOp != "") {
                    val tokens = clean.split(foundOp)
                    if (tokens.size == 2) {
                        val num1 = tokens[0].toDoubleOrNull() ?: 0.0
                        val num2 = tokens[1].toDoubleOrNull() ?: 0.0
                        val result = when (foundOp) {
                            "+" -> num1 + num2
                            "-" -> num1 - num2
                            "*" -> num1 * num2
                            "/" -> if (num2 != 0.0) num1 / num2 else 0.0
                            else -> num1
                        }
                        if (result % 1.0 == 0.0) result.toLong().toString() else "%.2f".format(result)
                    } else clean
                } else clean
            }
        } catch (_: Exception) {
            expr
        }
    }

    fun calculatePercent(expr: String): String {
        return try {
            val clean = expr.replace("×", "*").replace("÷", "/")
            val ops = listOf("*", "/", "+", "-")
            for (op in ops) {
                if (clean.contains(op) && !clean.startsWith(op)) {
                    val parts = clean.split(op)
                    if (parts.size == 2 && parts[1] != "") {
                        val a = parts[0].toDoubleOrNull() ?: 0.0
                        val b = parts[1].toDoubleOrNull() ?: 0.0
                        val res = when (op) {
                            "*" -> a * (b / 100.0)
                            "/" -> if (b != 0.0) a / (b / 100.0) else 0.0
                            "+" -> a + (a * b / 100.0)
                            "-" -> a - (a * b / 100.0)
                            else -> b
                        }
                        return if (res % 1.0 == 0.0) res.toLong().toString() else "%.2f".format(res)
                    }
                }
            }
            val num = clean.toDoubleOrNull()
            if (num != null) {
                val res = num / 100.0
                if (res % 1.0 == 0.0) res.toLong().toString() else "%.2f".format(res)
            } else expr
        } catch (_: Exception) {
            expr
        }
    }

    fun handleKeyPress(key: String) {
        when (key) {
            "C" -> expressionText = ""
            "⌫" -> if (expressionText != "") expressionText = expressionText.dropLast(1)
            "=" -> {
                if (expressionText != "") {
                    expressionText = evaluateExpression(expressionText)
                }
            }
            "%" -> {
                if (expressionText != "") {
                    expressionText = calculatePercent(expressionText)
                }
            }
            "+", "-", "×", "÷" -> {
                if (expressionText != "") {
                    val lastChar = expressionText.last().toString()
                    if (lastChar in listOf("+", "-", "×", "÷")) {
                        expressionText = expressionText.dropLast(1) + key
                    } else {
                        expressionText = evaluateExpression(expressionText) + key
                    }
                }
            }
            "." -> {
                if (!expressionText.endsWith(".")) {
                    expressionText = if (expressionText.isEmpty()) "0." else expressionText + "."
                }
            }
            else -> {
                if (expressionText.count() < 15) {
                    expressionText += key
                }
            }
        }
    }

    val finalAmount = remember(expressionText) {
        try {
            val eval = evaluateExpression(expressionText)
            eval.toDoubleOrNull()?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else "%.2f".format(it)
            } ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP SECTION: Header with Gallery QR Picker, Lang, Theme
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .shadow(4.dp, RoundedCornerShape(10.dp))
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = palette.onPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = Strings.get("app_title", language),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                    }

                    // Top Action Buttons: Gallery QR Picker + Language + Theme
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Gallery QR Picker Button
                        IconButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(38.dp)
                                .shadow(2.dp, CircleShape)
                                .background(palette.surface, CircleShape)
                                .border(1.dp, palette.border, CircleShape)
                        ) {
                            Box(
                                modifier = Modifier.size(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🖼",
                                    fontSize = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Language Selector
                        Box {
                            IconButton(
                                onClick = { langMenuExpanded = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .shadow(2.dp, CircleShape)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Text(
                                    text = "文A",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                            }
                            DropdownMenu(
                                expanded = langMenuExpanded,
                                onDismissRequest = { langMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppLanguage.values().forEach { lang ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                lang.displayName,
                                                fontWeight = if (lang == language) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onLanguageChange(lang)
                                            langMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Theme Selector
                        Box {
                            IconButton(
                                onClick = { themeMenuExpanded = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .shadow(2.dp, CircleShape)
                                    .background(palette.surface, CircleShape)
                                    .border(1.dp, palette.border, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Theme",
                                    tint = palette.accent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = themeMenuExpanded,
                                onDismissRequest = { themeMenuExpanded = false },
                                modifier = Modifier.background(palette.surface)
                            ) {
                                AppThemeMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                mode.title,
                                                fontWeight = if (mode == themeMode) FontWeight.Bold else FontWeight.Normal,
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            onThemeChange(mode)
                                            themeMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // UPI Selector + Add Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(2.dp, RoundedCornerShape(12.dp))
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.surface)
                                .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                                .clickable { upiMenuExpanded = true }
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = selectedAccount.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = selectedAccount.upiId,
                                    fontSize = 11.sp,
                                    color = palette.textSecondary
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = palette.primary)
                        }

                        // Dropdown with EDIT and DELETE Options
                        DropdownMenu(
                            expanded = upiMenuExpanded,
                            onDismissRequest = { upiMenuExpanded = false },
                            modifier = Modifier.background(palette.surface)
                        ) {
                            upiAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                                                Text(acc.upiId, fontSize = 11.sp, color = palette.textSecondary)
                                            }
                                            // Edit Button
                                            IconButton(
                                                onClick = {
                                                    accountToEdit = acc
                                                    upiMenuExpanded = false
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = palette.accent, modifier = Modifier.size(16.dp))
                                            }
                                            // Delete Button
                                            if (upiAccounts.size > 1) {
                                                IconButton(
                                                    onClick = {
                                                        val remaining = upiAccounts.filter { it.id != acc.id }
                                                        val nextActive = if (selectedAccountId == acc.id) remaining.first().id else selectedAccountId
                                                        saveAccounts(remaining, nextActive)
                                                        Toast.makeText(context, "Account deleted", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    },
                                    onClick = {
                                        saveAccounts(upiAccounts, acc.id)
                                        upiMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { showAddUpiDialog = true },
                        modifier = Modifier
                            .size(36.dp)
                            .shadow(2.dp, RoundedCornerShape(10.dp))
                            .background(palette.surfaceVariant, RoundedCornerShape(10.dp))
                            .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add UPI", tint = palette.primary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Notes Field
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    placeholder = {
                        Text(
                            Strings.get("notes_placeholder", language),
                            fontSize = 12.sp,
                            color = palette.textSecondary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = palette.surface,
                        unfocusedContainerColor = palette.surface,
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() }
                    ),
                    trailingIcon = {
                        if (noteText != "") {
                            IconButton(onClick = { noteText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Luxury Amount Display Card (Sapphire Slate & Gold)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .shadow(4.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.displayCardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "₹",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.displayCardCurrency
                        )
                        Text(
                            text = if (expressionText.isEmpty()) "0" else expressionText,
                            fontSize = if (expressionText.count() > 8) 26.sp else 34.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.displayCardAmount,
                            textAlign = TextAlign.End
                        )
                    }
                }
            }

            // BOTTOM SECTION: Full 5-Row Keypad (~50% height) + Generate Button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CalculatorKeypad(
                    modifier = Modifier.weight(1f),
                    palette = palette,
                    onKeyPress = { handleKeyPress(it) }
                )

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = { showQrPopup = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .shadow(8.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.primary,
                        contentColor = palette.onPrimary
                    )
                ) {
                    Text(
                        text = "⚡  " + Strings.get("generate_qr", language),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }

        // QR Code Modal (Optimized for Car Tablet & Phone Viewports)
        if (showQrPopup) {
            QrPopupModal(
                isOpen = showQrPopup,
                onDismiss = { showQrPopup = false },
                amount = finalAmount,
                note = noteText,
                currentAccount = selectedAccount,
                allAccounts = upiAccounts,
                onAccountChange = { saveAccounts(upiAccounts, it.id) },
                palette = palette,
                lang = language
            )
        }

        // Add New UPI Dialog
        if (showAddUpiDialog) {
            var newName by remember { mutableStateOf("") }
            var newUpiId by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddUpiDialog = false },
                containerColor = palette.surface,
                title = { Text(Strings.get("add_new_upi", language), fontWeight = FontWeight.Bold, color = palette.textPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text(Strings.get("merchant_name", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = newUpiId,
                            onValueChange = { newUpiId = it },
                            label = { Text("UPI ID") },
                            placeholder = { Text(Strings.get("upi_id_hint", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val cleanName = newName.trim()
                            val cleanUpi = newUpiId.trim()
                            if (cleanName != "" && cleanUpi != "") {
                                val isDuplicate = upiAccounts.any { it.upiId.equals(cleanUpi, ignoreCase = true) }
                                if (isDuplicate) {
                                    Toast.makeText(context, "Already Added!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val acc = UpiAccount(
                                        id = System.currentTimeMillis().toString(),
                                        name = cleanName,
                                        upiId = cleanUpi
                                    )
                                    val updated = upiAccounts + acc
                                    saveAccounts(updated, acc.id)
                                    showAddUpiDialog = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary)
                    ) {
                        Text(Strings.get("save", language), color = palette.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddUpiDialog = false }) {
                        Text(Strings.get("cancel", language), color = palette.textSecondary)
                    }
                }
            )
        }

        // Edit Existing UPI Account Dialog
        if (accountToEdit != null) {
            val acc = accountToEdit!!
            var editName by remember { mutableStateOf(acc.name) }
            var editUpiId by remember { mutableStateOf(acc.upiId) }

            AlertDialog(
                onDismissRequest = { accountToEdit = null },
                containerColor = palette.surface,
                title = { Text("Edit UPI Account", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text(Strings.get("merchant_name", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = editUpiId,
                            onValueChange = { editUpiId = it },
                            label = { Text("UPI ID") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val cleanName = editName.trim()
                            val cleanUpi = editUpiId.trim()
                            if (cleanName != "" && cleanUpi != "") {
                                val isDuplicate = upiAccounts.any { it.id != acc.id && it.upiId.equals(cleanUpi, ignoreCase = true) }
                                if (isDuplicate) {
                                    Toast.makeText(context, "Already Added!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val updated = upiAccounts.map {
                                        if (it.id == acc.id) it.copy(name = cleanName, upiId = cleanUpi) else it
                                    }
                                    saveAccounts(updated, selectedAccountId)
                                    accountToEdit = null
                                    Toast.makeText(context, "Account updated", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary)
                    ) {
                        Text(Strings.get("save", language), color = palette.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { accountToEdit = null }) {
                        Text(Strings.get("cancel", language), color = palette.textSecondary)
                    }
                }
            )
        }

        // Scanned QR "Add to Account" Dialog (Pre-filled + auto-copied!)
        if (showScannedDialog) {
            AlertDialog(
                onDismissRequest = { showScannedDialog = false },
                containerColor = palette.surface,
                title = { Text("Add Scanned QR to Accounts", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("UPI ID has been copied to your clipboard!", fontSize = 12.sp, color = palette.accent, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = scannedName,
                            onValueChange = { scannedName = it },
                            label = { Text(Strings.get("merchant_name", language)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = scannedUpiId,
                            onValueChange = { scannedUpiId = it },
                            label = { Text("UPI ID") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val cleanName = scannedName.trim()
                            val cleanUpi = scannedUpiId.trim()
                            if (cleanName != "" && cleanUpi != "") {
                                val isDuplicate = upiAccounts.any { it.upiId.equals(cleanUpi, ignoreCase = true) }
                                if (isDuplicate) {
                                    Toast.makeText(context, "Already Added!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val acc = UpiAccount(
                                        id = System.currentTimeMillis().toString(),
                                        name = cleanName,
                                        upiId = cleanUpi
                                    )
                                    val updated = upiAccounts + acc
                                    saveAccounts(updated, acc.id)
                                    showScannedDialog = false
                                    Toast.makeText(context, "Saved: ${acc.name}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary)
                    ) {
                        Text("Add to Accounts", color = palette.onPrimary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showScannedDialog = false }) {
                        Text(Strings.get("cancel", language), color = palette.textSecondary)
                    }
                }
            )
        }
    }
}


// Self-contained QR decoder helpers directly inside HomeScreen
fun decodeQrFromUri(context: android.content.Context, uri: android.net.Uri): String? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
        inputStream.close()
        if (bitmap == null) return null

        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val source = com.google.zxing.RGBLuminanceSource(width, height, pixels)
        val binaryBitmap = com.google.zxing.BinaryBitmap(com.google.zxing.common.HybridBinarizer(source))
        val result = com.google.zxing.MultiFormatReader().decode(binaryBitmap)
        result.text
    } catch (e: Exception) {
        null
    }
}

fun parseUpiDetails(qrText: String): Pair<String, String> {
    return try {
        if (qrText.startsWith("upi://pay")) {
            val uri = android.net.Uri.parse(qrText)
            val pa = uri.getQueryParameter("pa") ?: ""
            val pn = uri.getQueryParameter("pn") ?: "Scanned Store"
            Pair(pn, pa)
        } else if (qrText.contains("@")) {
            Pair("Scanned Account", qrText.trim())
        } else {
            Pair("Scanned Store", qrText.trim())
        }
    } catch (_: Exception) {
        Pair("Scanned Store", qrText.trim())
    }
}