package com.upiqr.generator.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.upiqr.generator.theme.CustomPalette

@Composable
fun CalculatorKeypad(
    modifier: Modifier = Modifier,
    palette: CustomPalette,
    onKeyPress: (String) -> Unit
) {
    val view = LocalView.current

    // 5-Row Full Calculator Grid
    val rows = listOf(
        listOf("C", "⌫", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("0", ".", "=")
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(palette.keyDeckBackground)
            .border(1.dp, palette.border, RoundedCornerShape(20.dp))
            .padding(6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            rows.forEach { rowKeys ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    rowKeys.forEach { key ->
                        val isOperator = key in listOf("÷", "×", "-", "+", "=")
                        val isClear = key in listOf("C", "⌫", "%")
                        
                        val bgColor = when {
                            isOperator -> palette.keyOperatorBackground
                            isClear -> palette.keyClearBackground
                            else -> palette.keyBackground
                        }
                        val textColor = when {
                            isOperator -> palette.keyOperatorText
                            isClear -> palette.keyClearText
                            else -> palette.keyText
                        }

                        // In row 5, '0' takes weight 2 for extra wide comfortable thumb press
                        val buttonWeight = if (key == "0") 2f else 1f

                        Box(
                            modifier = Modifier
                                .weight(buttonWeight)
                                .fillMaxHeight()
                                .shadow(2.dp, RoundedCornerShape(14.dp))
                                .clip(RoundedCornerShape(14.dp))
                                .background(bgColor)
                                .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                                .clickable {
                                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                    onKeyPress(key)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = key,
                                fontSize = if (key in listOf("÷", "×", "-", "+", "=")) 24.sp else 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = textColor
                            )
                        }
                    }
                }
            }
        }
    }
}
